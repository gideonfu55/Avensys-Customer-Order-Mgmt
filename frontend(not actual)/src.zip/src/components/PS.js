import React, { useEffect, useState } from 'react';
import NavBar from './NavBar';
import { Modal } from 'react-bootstrap';
import ViewPO from './ViewPO';
import CreateInvoice from './CreateInvoice';
import './ES.css';
import axios from 'axios';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEye, faPlus, faEdit, faTrash } from '@fortawesome/free-solid-svg-icons';
import EditPO from './EditPO';

function PS() {
  const [PS, setPS] = useState([]);
  const [showPOModal, setShowPOModal] = useState(false);
  const [showInvoiceModal, setShowInvoiceModal] = useState(false);
  const [selectedPO, setSelectedPO] = useState(null);
  const [selectedStatus, setSelectedStatus] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [searchType, setSearchType] = useState('poNumber');
  const [showEditModal, setShowEditModal] = useState(false);

  function handleShowPOModalClose() {
    setShowPOModal(false);
  }

  function handleShowInvoiceModalClose() {
    setShowInvoiceModal(false);
  }

  function handleStatusChange(e) {
    setSelectedStatus(e.target.value);
  }

  const handleSearchTermChange = (e) => {
    setSearchTerm(e.target.value);
  };

  const handleSearchTypeChange = (e) => {
    setSearchType(e.target.value);
  };

  useEffect(() => {
    axios
      .get('http://localhost:8080/api/po/all', { maxRedirects: 5 })
      .then((response) => {
        setPS(response.data);
      })
      .catch((error) => {
        console.error(error);
      });

    console.log('PS POs: ', PS);
  }, []);

  const filteredPS = selectedStatus
    ? PS.filter((po) => po.status === selectedStatus && po.type === 'Talent Service')
    : PS.filter((po) => po.type === 'Talent Service' || po.type === 'Professional Service');

  const handleDeletePO = (id) => {
    axios
      .delete(`http://localhost:8080/api/po/delete/${id}`)
      .then((response) => {
        setPS((prevPS) => prevPS.filter((po) => po.id !== id));
      })
      .catch((error) => {
        console.error(error);
      });
  };

  const handleEditPO = (po) => {
    setSelectedPO(po);
    setShowEditModal(true);
  };

  return (
    <div className='dashboard-body'>
      <NavBar />
      <div className='dashboard-content'>
        <div className='ps-intro'>
          <h2>
            <span style={{ fontWeight: '800' }}>Professional Services:</span>{' '}
            <span style={{ fontWeight: '200' }}>Purchase Orders</span>
          </h2>
          <button type='button' className='btn btn-dark'>
            Back
          </button>
        </div>

        {/* Filter by status */}
        <div className='status-filter'>
          <label htmlFor='status-select'>Filter by Status:</label>
          <select id='status-select' className='form-control' value={selectedStatus} onChange={handleStatusChange}>
            <option value=''>All</option>
            <option value='Outstanding'>Outstanding</option>
            <option value='Completed'>Completed</option>
            <option value='Cancelled'>Cancelled</option>
          </select>
        </div>

        <div className="search-wrapper">
          <label htmlFor='search-box'>Search:</label>
          <form className="d-flex">
            <select
              style={{ width: 100 }}
              id='search-type-select'
              className='form-control'
              value={searchType}
              onChange={handleSearchTypeChange}
            >
              <option value='poNumber'>PO#</option>
              <option value='clientName'>Client</option>
            </select>
            <input
              id='search-box'
              type='text'
              className='form-control search'
              placeholder='Search...'
              value={searchTerm}
              onChange={handleSearchTermChange}
            />
          </form>
        </div>

        {/* Table of PS PO's */}
        <table className='table table-light table-hover'>
          <thead>
            <tr>
              <th scope='col' className='text-center'>PO #</th>
              <th scope='col' className='text-center'>Client</th>
              <th scope='col' className='text-center'>Type</th>
              <th scope='col' className='text-center'>Start Date</th>
              <th scope='col' className='text-center'>End Date</th>
              <th scope='col' className='text-center'>Milestone (%)</th>
              <th scope='col' className='text-center'>Total Value</th>
              <th scope='col' className='text-center'>Balance Value</th>
              <th scope='col' className='text-center'>
                <span>Status</span>
                <i className='fas fa-filter'></i>
              </th>
              <th scope='col'></th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {filteredPS
              .filter((po) =>
                po[searchType]
                  .toString()
                  .toLowerCase()
                  .includes(searchTerm.toLowerCase())
              )
              .map((po) => (
                <tr key={po.id}>
                  <td className='text-center'>{po.poNumber}</td>
                  <td className='text-center'>{po.clientName}</td>
                  <td className='text-center'>{po.type}</td>
                  <td className='text-center'>{po.startDate}</td>
                  <td className='text-center'>{po.endDate}</td>
                  <td className='text-center'>{po.milestone}</td>
                  <td className='text-center'>{po.totalValue}</td>
                  <td className='text-center'>{po.balValue}</td>
                  <td className='text-center'>{po.status}</td>
                  <td></td>
                  <td>
                    <div className='button-container'>
                      <button
                        type='button'
                        className='btn btn-dark'
                        onClick={() => {
                          setSelectedPO(po);
                          setShowPOModal(true);
                        }}
                      >
                        <FontAwesomeIcon icon={faEye} />
                      </button>
                      <button
                      type='button'
                      className='btn btn-dark'
                      onClick={() => handleEditPO(po)} 
                    >
                      <FontAwesomeIcon icon={faEdit} />
                    </button>

                      <button
                        type='button'
                        className='btn btn-dark'
                        onClick={() => {
                          setSelectedPO(po);
                          setShowInvoiceModal(true);
                        }}
                      >
                        <FontAwesomeIcon icon={faPlus} />
                      </button>
                      <button
                        className='btn btn-dark'
                        onClick={() => handleDeletePO(po.id)}
                      >
                        <FontAwesomeIcon icon={faTrash} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
          </tbody>
        </table>

        {/* View PO Modal */}
        <Modal show={showPOModal} onHide={handleShowPOModalClose} dialogClassName='custom-modal'>
          <Modal.Header closeButton>
            <Modal.Title>Purchase Order</Modal.Title>
          </Modal.Header>
          <Modal.Body>{showPOModal && <ViewPO selectedPO={selectedPO} closeModal={handleShowPOModalClose} />}</Modal.Body>
        </Modal>

        {/* Create Invoice Modal */}
        <Modal show={showInvoiceModal} onHide={handleShowInvoiceModalClose} dialogClassName='custom-modal w-50'>
          <Modal.Header closeButton>
            <Modal.Title>Create Invoice</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            {showInvoiceModal && <CreateInvoice selectedPO={selectedPO} closeModal={handleShowInvoiceModalClose} />}
          </Modal.Body>
        </Modal>

        {/* Edit PO Modal */}
        <Modal show={showEditModal} onHide={() => setShowEditModal(false)} dialogClassName='custom-modal w-50'>
            <Modal.Header closeButton>
              <Modal.Title>Edit Purchase Order</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              {showEditModal && <EditPO selectedPO={selectedPO} closeModal={() => setShowEditModal(false)} />}
            </Modal.Body>
          </Modal>
      </div>
    </div>
  );
}

export default PS;
